#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/ledc.h"
#include "driver/adc.h"

#define LED_GPIO         GPIO_NUM_14
#define POT_ADC_CHANNEL  ADC1_CHANNEL_6  // GPIO34

// Resolución de PWM en bits (2^10 = 1024 niveles)
#define PWM_RES_BITS     LEDC_TIMER_10_BIT
#define PWM_MAX_DUTY     ((1 << PWM_RES_BITS) - 1)  // 1023

void app_main(void)
{
    // Configurar PWM para el LED en GPIO14
    ledc_timer_config_t pwm_timer = {
        .speed_mode       = LEDC_LOW_SPEED_MODE,
        .timer_num        = LEDC_TIMER_0,
        .duty_resolution  = PWM_RES_BITS,
        .freq_hz          = 5000,  // Frecuencia para LED (no parpadea)
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ledc_timer_config(&pwm_timer);

    ledc_channel_config_t pwm_channel = {
        .gpio_num       = LED_GPIO,
        .speed_mode     = LEDC_LOW_SPEED_MODE,
        .channel        = LEDC_CHANNEL_0,
        .timer_sel      = LEDC_TIMER_0,
        .duty           = 0,
        .hpoint         = 0
    };
    ledc_channel_config(&pwm_channel);

    // Configurar ADC para el potenciómetro
    adc1_config_width(ADC_WIDTH_BIT_10); // 0-1023
    adc1_config_channel_atten(POT_ADC_CHANNEL, ADC_ATTEN_DB_11); // hasta 3.3V

    while (1) {
        int pot_value = adc1_get_raw(POT_ADC_CHANNEL);

        // Escalar valor del potenciómetro al rango de PWM (0-1023)
        int duty = (pot_value * PWM_MAX_DUTY) / 1023;

        ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);

        printf("Potenciómetro: %d -> PWM duty: %d\n", pot_value, duty);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}