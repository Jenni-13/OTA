
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "esp_system.h"
#include "esp_partition.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "protocol_examples_common.h"

#include "esp_log.h"
#include "mqtt_client.h"
#include "esp_tls.h"
#include "esp_ota_ops.h"
#include <sys/param.h>
#include <inttypes.h>

static const char *TAG = "mqtts_example";

#if CONFIG_BROKER_CERTIFICATE_OVERRIDDEN == 1
static const uint8_t mqtt_eclipseprojects_io_pem_start[]  = "-----BEGIN CERTIFICATE-----\n" CONFIG_BROKER_CERTIFICATE_OVERRIDE "\n-----END CERTIFICATE-----";
#else
extern const uint8_t emqxsl_ca_pem_start[]   asm("_binary_emqxsl_ca_pem_start");
#endif
extern const uint8_t emqxsl_ca_pem_end[]   asm("_binary_emqxsl_ca_pem_end");

static esp_mqtt_client_handle_t mqtt_client = NULL;

static void process_mqtt_message(const char* topic, const char* data, int data_len)
{
    // Buffer para almacenar datos del mensaje de forma segura
    char message_data[256];
    
    // Copia segura: evita buffer overflow y asegura null-termination
    int copy_len = MIN(data_len, sizeof(message_data) - 1);
    memcpy(message_data, data, copy_len);
    message_data[copy_len] = '\0';  // CRÍTICO: null-termination manual
    
    ESP_LOGI(TAG, "Processing message - Topic: %s, Data: %s", topic, message_data);
    
    /* CONDICIÓN 1: Verificar tópico específico
     * strcmp() retorna 0 si las cadenas son idénticas
     * IMPORTANTE: El tópico debe coincidir EXACTAMENTE */
    if (strcmp(topic, "/class/idgs11/available") == 0) {
        ESP_LOGI(TAG, "Received message on availability topic");
        
        /* CONDICIÓN 2: Verificar valor específico
         * Solo responde si el valor es exactamente "true"
         * Sensible a mayúsculas/minúsculas: "True", "TRUE" NO activarán */
        if (strcmp(message_data, "true") == 0) {
            ESP_LOGI(TAG, "Available = true detected, sending response...");
            
            // Configuración de la respuesta automática
            const char* response_topic = "/class/idgs11/assistants";  // Tópico destino
            const char* response_message = "2022371065";               // Mensaje fijo
            
            /* Publicación del mensaje de respuesta
             * Parámetros de esp_mqtt_client_publish():
             * - mqtt_client: Handle del cliente (variable global)
             * - response_topic: Tópico donde publicar
             * - response_message: Mensaje a enviar
             * - strlen(): Longitud del mensaje
             * - 1: QoS level (0=at most once, 1=at least once, 2=exactly once)
             * - 0: retain flag (0=no retener, 1=retener último mensaje) */
            int msg_id = esp_mqtt_client_publish(mqtt_client, response_topic, response_message, 
                                               strlen(response_message), 1, 0);
            
            // Verificación del resultado de la publicación
            if (msg_id != -1) {
                ESP_LOGI(TAG, "Response sent successfully to %s with message: %s (msg_id=%d)", 
                        response_topic, response_message, msg_id);
            } else {
                ESP_LOGE(TAG, "Failed to send response message");
            }
        } else {
            // Log informativo: valor recibido pero no es "true"
            ESP_LOGI(TAG, "Available = %s (not true), no response sent", message_data);
        }
    }
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data)
{
    ESP_LOGD(TAG, "Event dispatched from event loop base=%s, event_id=%" PRIi32, base, event_id);
    esp_mqtt_event_handle_t event = event_data;
    esp_mqtt_client_handle_t client = event->client;
    int msg_id;
    switch ((esp_mqtt_event_id_t)event_id) {
    case MQTT_EVENT_CONNECTED:
        ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
        msg_id = esp_mqtt_client_subscribe(client, "/class/#", 1);
        ESP_LOGI(TAG, "sent subscribe successful, msg_id=%d", msg_id); 
        break;    
        
    /* ========================================================================
     * EVENTO: MENSAJE RECIBIDO - PARTE MÁS IMPORTANTE
     * Aquí llegan TODOS los mensajes de nuestras suscripciones
     * ======================================================================== */
    case MQTT_EVENT_DATA:
        ESP_LOGI(TAG, "MQTT_EVENT_DATA");
        
        /* PROBLEMA: Los datos del evento NO están null-terminated
         * event->topic y event->data son buffers RAW, no strings C válidas
         * SOLUCIÓN: Crear buffers locales con null-termination */
        
        char topic_str[256];  // Buffer para tópico
        char data_str[512];   // Buffer para datos del mensaje
        
        /* Copia segura del tópico
         * MIN() evita buffer overflow si el tópico es muy largo */
        int topic_len = MIN(event->topic_len, sizeof(topic_str) - 1);
        memcpy(topic_str, event->topic, topic_len);
        topic_str[topic_len] = '\0';  // Null-termination manual OBLIGATORIA
        
        /* Copia segura de los datos del mensaje */
        int data_len = MIN(event->data_len, sizeof(data_str) - 1);
        memcpy(data_str, event->data, data_len);
        data_str[data_len] = '\0';    // Null-termination manual OBLIGATORIA
        
        /* Output para debugging - útil durante desarrollo */
        printf("TOPIC=%s\r\n", topic_str);
        printf("DATA=%s\r\n", data_str);
        
        /* LLAMADA A LA FUNCIÓN DE PROCESAMIENTO
         * Aquí es donde ocurre la magia de la respuesta automática */
        process_mqtt_message(topic_str, data_str, event->data_len);
        
        break;
        // ... continua con el error y el default
                default:
            ESP_LOGW(TAG, "Unhandled event id: %" PRId32, event_id);
            break;
    }
}

static void mqtt_app_start(void)
{
    /* 🔧 DECLARACIÓN del cliente MQTT con configuración mínima 
     * IMPORTANTE: Modifica el URI del broker si usas otro */
esp_mqtt_client_config_t mqtt_cfg = {
    .broker = {
        .address.uri = "mqtts://l46d1e5e.ala.us-east-1.emqxsl.com", 
        .verification.certificate = (const char *)emqxsl_ca_pem_start
    },
    .credentials = {
        .username = "big-data-001",
        .authentication.password = "1Q2W3E4R5T6Y"
    }
};

    /* Inicialización del cliente MQTT */
    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);

    /* Registro del manejador de eventos */
    esp_mqtt_client_register_event(mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);

    /* Inicio del cliente MQTT */
    esp_mqtt_client_start(mqtt_client);
}

void app_main(void)
{
    ESP_LOGI(TAG, "[APP] Startup..");
    ESP_LOGI(TAG, "[APP] Free memory: %" PRIu32 " bytes", esp_get_free_heap_size());
    ESP_LOGI(TAG, "[APP] IDF version: %s", esp_get_idf_version());

    esp_log_level_set("*", ESP_LOG_INFO);
    esp_log_level_set("esp-tls", ESP_LOG_VERBOSE);
    esp_log_level_set("mqtt_client", ESP_LOG_VERBOSE);
    esp_log_level_set("mqtt_example", ESP_LOG_VERBOSE);

    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    ESP_ERROR_CHECK(example_connect());

    mqtt_app_start();
}